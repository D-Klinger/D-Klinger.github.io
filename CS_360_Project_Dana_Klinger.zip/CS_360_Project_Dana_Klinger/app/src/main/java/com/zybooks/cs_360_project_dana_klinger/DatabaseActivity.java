package com.zybooks.cs_360_project_dana_klinger;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DatabaseActivity extends AppCompatActivity {

    // DB manager to handle CRUD operations
    private DBManager dbManager;

    // Layout call to populate inventory view dynamically
    private GridLayout inventoryGrid;

    // Codes for SMS permissions and notifications
    private static final int SMS_PERMISSION_CODE = 1001;
    private static final int NOTIFICATION_PERMISSION_CODE = 1003;

    // Stores phone number and item name for SMS
    private String pendingSMSPhone;
    private String pendingSMSItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set UI layout
        setContentView(R.layout.activity_database);
        // Initialize DB manager
        dbManager = new DBManager(this);
        // Sets GridLayout view for items to appear
        inventoryGrid = findViewById(R.id.inventory_grid);
        // Set Android notification system
        createNotificationChannel();
        // Ask for notification permission
        requestNotificationPermissionIfNeeded();

        // Floating action button for adding new items
        FloatingActionButton fab = findViewById(R.id.fab_button);

        // Sets FAB behavior for item name and quantity when clicked
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Layout for user input fields for adding items
                LinearLayout layout = new LinearLayout(DatabaseActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                // Set padding on layout
                layout.setPadding(50, 20, 50, 10);

                // Text field for item name
                final EditText nameInput = new EditText(DatabaseActivity.this);
                nameInput.setHint("Item Name");
                nameInput.setInputType(InputType.TYPE_CLASS_TEXT);
                layout.addView(nameInput);

                // Text field for item quantity
                final EditText quantityInput = new EditText(DatabaseActivity.this);
                quantityInput.setHint("Initial Quantity");
                quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
                layout.addView(quantityInput);

                // Build and create new dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(DatabaseActivity.this);
                builder.setTitle("Add New Item");
                builder.setView(layout);

                builder.setPositiveButton("Add", (dialog, which) -> {
                    // Set values when 'Add' is clicked by user
                    String name = nameInput.getText().toString().trim();
                    String quantityStr = quantityInput.getText().toString().trim();

                    // Validate user input has name and quantity
                    if (name.isEmpty() || quantityStr.isEmpty()) {
                        Toast.makeText(DatabaseActivity.this, "Name and quantity are needed", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Insert item into DB
                    int quantity = Integer.parseInt(quantityStr);
                    dbManager.addItem(name, quantity);
                    loadInventory();
                });
                // Cancels and closes dialog for adding item
                builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

                // Show dialog
                AlertDialog dialog = builder.create();
                dialog.show();
                nameInput.requestFocus();
                dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            }
        });
        // Set and create the grid on activity start
        loadInventory();
    }

    // Dynamically load and display inventory items from the database
    private void loadInventory() {
        // Clear existing item view
        inventoryGrid.removeAllViews();
        // Query all items in database
        Cursor cursor = dbManager.getAllItems();

        while (cursor.moveToNext()) {
            // Inflate the item view layout
            View itemView = LayoutInflater.from(this).inflate(R.layout.item_inventory, inventoryGrid, false);

            // Gets fields from database
            int itemId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            // Set text to item name and quantity views
            TextView itemNameText = itemView.findViewById(R.id.item_name);
            TextView itemQtyText = itemView.findViewById(R.id.item_quantity);
            itemNameText.setText(itemName);
            itemQtyText.setText("Quantity: " + quantity);

            // Increase quantity button to increment quantity
            Button increaseButton = itemView.findViewById(R.id.button_increase);
            increaseButton.setOnClickListener(v -> {
                dbManager.updateItemQuantity(itemId, quantity + 1);
                loadInventory();
            });

            // Decrease quantity button to decrement quantity
            Button decreaseButton = itemView.findViewById(R.id.button_decrease);
            decreaseButton.setOnClickListener(v -> {
                int newQty = quantity - 1;

                // Update database with new item quantity
                if (newQty >= 0) {
                    dbManager.updateItemQuantity(itemId, newQty);
                    loadInventory();

                    // Bool to check if user allowed SMS alerts
                    boolean smsEnabled = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                            .getBoolean("sms_enabled", false);

                    // If statement to check stock < 2 and SMS is allowed, then send notification
                    if (newQty < 2 && smsEnabled) {
                        requestAndSendSMS("+1234567890", itemName);
                    }
                } else {
                    Toast.makeText(DatabaseActivity.this, "Quantity cannot be less than 0", Toast.LENGTH_SHORT).show();
                }
            });

            // Delete button to remove item from database
            Button deleteButton = itemView.findViewById(R.id.delete_button);
            deleteButton.setOnClickListener(v -> {
                dbManager.deleteItem(itemId);
                loadInventory();
            });

            // Adds item view to the grid layout
            inventoryGrid.addView(itemView);
        }
        // Cleanup of grid
        cursor.close();
    }

    // Request SMS permissions if not granted and send if granted permission
    private void requestAndSendSMS(String phoneNumber, String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSMS(phoneNumber, itemName);
        } else {
            pendingSMSPhone = phoneNumber;
            pendingSMSItem = itemName;

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    // Sends SMS and push notification to notification bar if permissions granted
    private void sendSMS(String phoneNumber, String itemName) {
        // Send actual SMS message - Not tested - unable on emulator!
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null,
                "Alert: Item '" + itemName + "' is low on stock.", null, null);

        // Build notification for notification bar
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "low_stock_channel")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Low Inventory Alert")
                .setContentText("Item '" + itemName + "' is running low.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        // Added check for POST_NOTIFICATIONS permission for Android API 13.0+
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            notificationManager.notify((int) System.currentTimeMillis(), builder.build());
        }

        // Toast display for confirmation
        Toast.makeText(this, "Low stock alert sent for: " + itemName, Toast.LENGTH_SHORT).show();
    }

    // Sets a notification channel for Android 8.0+ when using system alerts
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "LowStockAlerts";
            String description = "Channel for low stock item notifications";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel("low_stock_channel", name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    // Request permission to post notifications for Android 13.0+
    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_CODE);
            }
        }
    }

    // Handler for permission results
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMS(pendingSMSPhone, pendingSMSItem);
            } else {
                Toast.makeText(this, "SMS permission denied. Alerts will not be sent.", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == NOTIFICATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification permission denied. Alerts will not be sent to notification bar.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
