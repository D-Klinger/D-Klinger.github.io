package com.zybooks.cs_360_project_dana_klinger;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class UserRegisterActivity extends AppCompatActivity {

    // Fields for new username and password
    private EditText usernameInput;
    private EditText passwordInput;

    // Button for user registration
    private Button registerButton;

    // DB manager for updating database
    private DBManager dbManager;
    private static final int SMS_PERMISSION_CODE = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Starts activity lifecycle
        super.onCreate(savedInstanceState);
        // Set UI layout
        setContentView(R.layout.activity_register);

        // Sets input and buttons by id
        usernameInput = findViewById(R.id.register_username_input);
        passwordInput = findViewById(R.id.register_password_input);
        registerButton = findViewById(R.id.register_user_button);
        // Initialize and start database helper
        dbManager = new DBManager(this);

        // Sets register button behavior when clicked
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Trims input for username and password
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // Validation check for user fields in password and username
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(UserRegisterActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if able to insert user
                boolean success = dbManager.addUser(username, password);

                if (success) {
                    // Check for user to opt into SMS alerts
                    new AlertDialog.Builder(UserRegisterActivity.this)
                            .setTitle("Enable SMS Notifications?")
                            .setMessage("Would you like to receive alerts via SMS when inventory stock items are low?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                getSharedPreferences("AppPrefs", MODE_PRIVATE).edit().putBoolean("sms_enabled", true).apply();
                                requestSMSPermission();
                                goToLoginScreen();
                            })
                            .setNegativeButton("No", (dialog, which) -> {
                                getSharedPreferences("AppPrefs", MODE_PRIVATE).edit().putBoolean("sms_enabled", false).apply();
                                goToLoginScreen();
                            })
                            .setCancelable(false)
                            .show();
                } else {
                    Toast.makeText(UserRegisterActivity.this, "Username already exists.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Set system permission dialog
    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Returns user to login screen for initial login
    private void goToLoginScreen() {
        Intent intent = new Intent(UserRegisterActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
