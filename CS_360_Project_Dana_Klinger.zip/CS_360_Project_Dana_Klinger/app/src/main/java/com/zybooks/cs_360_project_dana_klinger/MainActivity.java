package com.zybooks.cs_360_project_dana_klinger;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// MainActivity handles login screen
public class MainActivity extends AppCompatActivity {

    // Fields to enter username, and password
    private EditText usernameInput;
    private EditText passwordInput;

    // Buttons for login action and register screen
    private Button loginButton;
    private Button createAccountButton;
    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Starts activity lifecycle
        super.onCreate(savedInstanceState);
        // Set UI layout for this screen to activity_main
        setContentView(R.layout.activity_main);

        // Find the EditText fields for username and password
        usernameInput = findViewById(R.id.username_edit_text);
        passwordInput = findViewById(R.id.password_edit_text);

        // Find the login button and stores reference to login button
        loginButton = findViewById(R.id.login_button);
        // Find the create account button and stores reference to create account button
        createAccountButton = findViewById(R.id.create_account_button);

        // Create a DBManager instance to work with SQLite DB
        dbManager = new DBManager(this);

        // Sets behavior of login button when clicked
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Trims input for username and password
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // Validation check for user fields in password and username
                if (username.isEmpty() || password.isEmpty()) {
                    // Notify user if fields are missing for username or password
                    Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Query DB to verify username and password
                boolean validLogin = dbManager.authenticateUser(username, password);

                // If user is verified, change to inventory screen
                if (validLogin) {
                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, DatabaseActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    // Notify user of incorrect credentials
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Sets behavior of create account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Change to the registration screen
                Intent intent = new Intent(MainActivity.this, UserRegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
